import { Link, useCanGoBack, useNavigate, useRouter, useRouterState } from "@tanstack/react-router";
import { Bookmark, ChevronLeft, GitCompare, House, ListChecks, Moon, Sun } from "lucide-react";
import { useEffect } from "react";
import { plainOf } from "@/data/simple";
import { useDesk } from "@/lib/desk";

const tabs = [
  { to: "/", label: "Home", icon: House, exact: true },
  { to: "/fit", label: "Marks", icon: ListChecks, exact: false },
  { to: "/compare", label: "Compare", icon: GitCompare, exact: false },
  { to: "/saved", label: "Saved", icon: Bookmark, exact: false },
] as const;

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const compareCount = useDesk((state) => state.compare.length);
  const savedCount = useDesk((state) => state.saved.length);
  const theme = useDesk((state) => state.theme);
  const setTheme = useDesk((state) => state.setTheme);
  const router = useRouter();
  const navigate = useNavigate();
  const canGoBack = useCanGoBack();
  const atHome = pathname === "/";

  useEffect(() => {
    void useDesk.persist.rehydrate();
  }, []);

  const heading = headingFor(pathname);

  return (
    <div className="min-h-dvh bg-bg text-cream">
      <header className="sticky top-0 z-20 border-b border-line bg-surface/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-3xl items-center gap-2 px-3">
          {atHome ? (
            <Link to="/" className="flex min-w-0 flex-1 items-baseline gap-1.5">
              <span className="font-display text-lg text-hot">LEVEL UP</span>
              <span className="font-display text-lg text-blue">Careers</span>
            </Link>
          ) : (
            <>
              <button
                type="button"
                onClick={() => {
                  if (canGoBack) router.history.back();
                  else void navigate({ to: "/" });
                }}
                className="flex h-11 shrink-0 items-center gap-0.5 pr-1 text-sm font-semibold text-cream"
              >
                <ChevronLeft className="size-6 text-hot" aria-hidden="true" />
                Back
              </button>
              <p className="min-w-0 flex-1 truncate text-center text-sm font-semibold">{heading}</p>
            </>
          )}
          <button
            type="button"
            aria-label={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="flex h-11 shrink-0 items-center gap-1 px-1 text-sm font-semibold text-blue"
          >
            {theme === "light" ? <Moon className="size-4" aria-hidden="true" /> : <Sun className="size-4" aria-hidden="true" />}
            {theme === "light" ? "Dark" : "Light"}
          </button>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl px-4 pb-24">{children}</main>
      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-surface/95 backdrop-blur-md">
        <ul className="mx-auto grid max-w-3xl grid-cols-4">
          {tabs.map((tab) => {
            const active = tab.exact ? pathname === tab.to : pathname.startsWith(tab.to);
            const Icon = tab.icon;
            const count = tab.to === "/compare" ? compareCount : tab.to === "/saved" ? savedCount : 0;
            return (
              <li key={tab.to}>
                <Link
                  to={tab.to}
                  className={
                    "flex h-14 flex-col items-center justify-center gap-0.5 text-xs font-medium " +
                    (active ? "text-hot" : "text-cream")
                  }
                >
                  <span className="relative">
                    <Icon className={"size-6 " + (active ? "fill-hot text-hot" : "")} aria-hidden="true" />
                    {count > 0 ? (
                      <span className="absolute -top-1.5 -right-2.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-blue px-1 text-xs font-semibold text-ink">
                        {count}
                      </span>
                    ) : null}
                  </span>
                  {tab.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

function headingFor(pathname: string): string {
  if (pathname.startsWith("/fit")) return "My marks";
  if (pathname.startsWith("/compare")) return "Compare";
  if (pathname.startsWith("/saved")) return "Saved";
  if (pathname.startsWith("/path/")) {
    const slug = pathname.slice("/path/".length);
    return plainOf(slug).title || "Course";
  }
  return "LEVEL UP Careers";
}
